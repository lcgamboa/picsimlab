/* This file contains no code; no further code is necessary for testing with the rcontrol interface of PICSimLab.*/
