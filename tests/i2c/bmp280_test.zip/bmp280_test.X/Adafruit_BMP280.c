/*!
 *  @file Adafruit_BMP280.cpp
 *
 *  This is a library for the BMP280 orientation sensor
 *
 *  Designed specifically to work with the Adafruit BMP280 Sensor.
 *
 *  Pick one up today in the adafruit shop!
 *  ------> https://www.adafruit.com/product/2651
 *
 *  These sensors use I2C to communicate, 2 pins are required to interface.
 *
 *  Adafruit invests time and resources providing this open source code,
 *  please support Adafruit andopen-source hardware by purchasing products
 *  from Adafruit!
 *
 *  K.Townsend (Adafruit Industries)
 *
 *  BSD license, all text above must be included in any redistribution
 */

#include "Adafruit_BMP280.h"
#include "spi.h"
#include "i2c.h"

/*!
 * @brief  BMP280 constructor using i2c
 * @param  *theWire
 *         optional wire
 */
void BMP280_INIT_I2C(Adafruit_BMP280 * bmp280, uint8_t addr) {
    bmp280->_i2caddr = addr;
    bmp280->_sensorID = 0;
    i2cBegin(addr, MASTER);
}

/*!
 * @brief  BMP280 constructor using hardware SPI
 * @param  cspin
 *         cs pin number
 * @param  theSPI
 *         optional SPI object
 */
void BMP280_INIT_SPI(Adafruit_BMP280 * bmp280, uint8_t cspin) {
    bmp280->_i2caddr = 0;
    bmp280->_sensorID = 0;
    spiBegin(cspin, MASTER_OSC_DIV64, SAMPLE_MIDDLE, IDLE_LOW, IDLE_TO_ACTIVE);
}

/*!
 *  Initialises the sensor.
 *  @param addr
 *         The I2C address to use (default = 0x77)
 *  @param chipid
 *         The expected chip ID (used to validate connection).
 *  @return True if the init was successful, otherwise false.
 */
int BMP280_begin(Adafruit_BMP280 * bmp280, uint8_t chipid) {

    // check if sensor, i.e. the chip ID is correct
    bmp280->_sensorID = BMP280_read8(bmp280, BMP280_REGISTER_CHIPID);
    if (bmp280->_sensorID != chipid)
        return 0;

    BMP280_readCoefficients(bmp280);
    // write8(BMP280_REGISTER_CONTROL, 0x3F); /* needed? */
    BMP280_setSampling(bmp280, MODE_NORMAL, SAMPLING_X16, SAMPLING_X16, FILTER_OFF, STANDBY_MS_1);
    delay(100);
    return 1;
}

/*!
 * Sets the sampling config for the device.
 * @param mode
 *        The operating mode of the sensor.
 * @param tempSampling
 *        The sampling scheme for temp readings.
 * @param pressSampling
 *        The sampling scheme for pressure readings.
 * @param filter
 *        The filtering mode to apply (if any).
 * @param duration
 *        The sampling duration.
 */
void BMP280_setSampling(Adafruit_BMP280 * bmp280, sensor_mode mode,
        sensor_sampling tempSampling,
        sensor_sampling pressSampling,
        sensor_filter filter,
        standby_duration duration) {
    if (!bmp280->_sensorID)
        return; // begin() not called yet
    bmp280->_measReg = 0;
    bmp280->_measReg |= mode;
    bmp280->_measReg |= tempSampling << 5;
    bmp280->_measReg |= pressSampling << 2;

    bmp280->_configReg = 0;
    bmp280->_configReg |= filter << 2;
    bmp280->_configReg |= duration << 5;

    BMP280_write8(bmp280, BMP280_REGISTER_CONFIG, bmp280->_configReg);
    BMP280_write8(bmp280, BMP280_REGISTER_CONTROL, bmp280->_measReg);
}

/**************************************************************************/
/*!
    @brief  Writes an 8 bit value over I2C/SPI
 */

/**************************************************************************/
void BMP280_write8(Adafruit_BMP280 * bmp280, uint8_t reg, uint8_t value) {
    uint8_t buffer[2];
    buffer[1] = value;
    if (bmp280->_i2caddr) {
        buffer[0] = reg;
        i2c_write(buffer, 2);
    } else {
        buffer[0] = reg & ~0x80;
        spi_write(buffer, 2);
    }
}

/*!
 *  @brief  Reads an 8 bit value over I2C/SPI
 *  @param  reg
 *          selected register
 *  @return value from selected register
 */
uint8_t BMP280_read8(Adafruit_BMP280 * bmp280, uint8_t reg) {
    uint8_t buffer[1];
    if (bmp280->_i2caddr) {
        buffer[0] = reg;
        i2c_write_then_read(buffer, 1, buffer, 1);
    } else {
        buffer[0] = reg | 0x80;
        spi_write_then_read(buffer, 1, buffer, 1);
    }
    return buffer[0];
}

/*!
 *  @brief  Reads a 16 bit value over I2C/SPI
 */
uint16_t BMP280_read16(Adafruit_BMP280 * bmp280, uint8_t reg) {
    uint8_t buffer[2];

    if (bmp280->_i2caddr) {
        buffer[0] = reg;
        i2c_write_then_read(buffer, 1, buffer, 2);
    } else {
        buffer[0] = reg | 0x80;
        spi_write_then_read(buffer, 1, buffer, 2);
    }
    return ((uint16_t) buffer[0]) << 8 | ((uint16_t) buffer[1]);
}

uint16_t BMP280_read16_LE(Adafruit_BMP280 * bmp280, uint8_t reg) {
    uint16_t temp = BMP280_read16(bmp280, reg);
    return (temp >> 8) | (temp << 8);
}

/*!
 *   @brief  Reads a signed 16 bit value over I2C/SPI
 */
int16_t BMP280_readS16(Adafruit_BMP280 * bmp280, uint8_t reg) {
    return (int16_t) BMP280_read16(bmp280, reg);
}

int16_t BMP280_readS16_LE(Adafruit_BMP280 * bmp280, uint8_t reg) {
    return (int16_t) BMP280_read16_LE(bmp280, reg);
}

/*!
 *  @brief  Reads a 24 bit value over I2C/SPI
 */
uint32_t BMP280_read24(Adafruit_BMP280 * bmp280, uint8_t reg) {
    uint8_t buffer[3];

    if (bmp280->_i2caddr) {
        buffer[0] = reg;
        i2c_write_then_read(buffer, 1, buffer, 3);
    } else {
        buffer[0] = reg | 0x80;
        spi_write_then_read(buffer, 1, buffer, 3);
    }
    return ((uint32_t) buffer[0]) << 16 | ((uint32_t) buffer[1]) << 8 |
            ((uint32_t) buffer[2]);
}

/*!
 *  @brief  Reads the factory-set coefficients
 */
void BMP280_readCoefficients(Adafruit_BMP280 * bmp280) {
    bmp280->_bmp280_calib.dig_T1 = BMP280_read16_LE(bmp280, BMP280_REGISTER_DIG_T1);
    bmp280->_bmp280_calib.dig_T2 = BMP280_readS16_LE(bmp280, BMP280_REGISTER_DIG_T2);
    bmp280->_bmp280_calib.dig_T3 = BMP280_readS16_LE(bmp280, BMP280_REGISTER_DIG_T3);

    bmp280->_bmp280_calib.dig_P1 = BMP280_read16_LE(bmp280, BMP280_REGISTER_DIG_P1);
    bmp280->_bmp280_calib.dig_P2 = BMP280_readS16_LE(bmp280, BMP280_REGISTER_DIG_P2);
    bmp280->_bmp280_calib.dig_P3 = BMP280_readS16_LE(bmp280, BMP280_REGISTER_DIG_P3);
    bmp280->_bmp280_calib.dig_P4 = BMP280_readS16_LE(bmp280, BMP280_REGISTER_DIG_P4);
    bmp280->_bmp280_calib.dig_P5 = BMP280_readS16_LE(bmp280, BMP280_REGISTER_DIG_P5);
    bmp280->_bmp280_calib.dig_P6 = BMP280_readS16_LE(bmp280, BMP280_REGISTER_DIG_P6);
    bmp280->_bmp280_calib.dig_P7 = BMP280_readS16_LE(bmp280, BMP280_REGISTER_DIG_P7);
    bmp280->_bmp280_calib.dig_P8 = BMP280_readS16_LE(bmp280, BMP280_REGISTER_DIG_P8);
    bmp280->_bmp280_calib.dig_P9 = BMP280_readS16_LE(bmp280, BMP280_REGISTER_DIG_P9);

    /*
        bmp280->_bmp280_calib.dig_T1 = 27504;
        bmp280->_bmp280_calib.dig_T2 = 26435;
        bmp280->_bmp280_calib.dig_T3 = -1000;

        bmp280->_bmp280_calib.dig_P1 = 36477;
        bmp280->_bmp280_calib.dig_P2 = -10685;
        bmp280->_bmp280_calib.dig_P3 = 3024;
        bmp280->_bmp280_calib.dig_P4 = 2855;
        bmp280->_bmp280_calib.dig_P5 = 140;
        bmp280->_bmp280_calib.dig_P6 = -7;
        bmp280->_bmp280_calib.dig_P7 = 15500;
        bmp280->_bmp280_calib.dig_P8 = -14600;
        bmp280->_bmp280_calib.dig_P9 = 6000;
     */
}

/*!
 * Reads the temperature from the device.
 * @return The temperature in degrees celsius.
 */
float BMP280_readTemperature(Adafruit_BMP280 * bmp280) {
    int32_t var1, var2;
    if (!bmp280->_sensorID)
        return 0; // begin() not called yet

    int32_t adc_T = (int32_t) BMP280_read24(bmp280, BMP280_REGISTER_TEMPDATA);
    adc_T >>= 4;

    var1 = ((((adc_T >> 3) - ((int32_t) bmp280->_bmp280_calib.dig_T1 << 1))) *
            ((int32_t) bmp280->_bmp280_calib.dig_T2)) >>
            11;

    var2 = (((((adc_T >> 4) - ((int32_t) bmp280->_bmp280_calib.dig_T1)) *
            ((adc_T >> 4) - ((int32_t) bmp280->_bmp280_calib.dig_T1))) >>
            12) *
            ((int32_t) bmp280->_bmp280_calib.dig_T3)) >>
            14;

    bmp280->t_fine = var1 + var2;

    float T = (bmp280->t_fine * 5 + 128) >> 8;
    return T / 100;
}

/*!
 * Reads the barometric pressure from the device.
 * @return Barometric pressure in Pa.
 */
float BMP280_readPressure(Adafruit_BMP280 * bmp280) {
    int64_t var1, var2, p;
    if (!bmp280->_sensorID)
        return 0; // begin() not called yet

    // Must be done first to get the t_fine variable set up
    BMP280_readTemperature(bmp280);

    int32_t adc_P = (int32_t) BMP280_read24(bmp280, BMP280_REGISTER_PRESSUREDATA);
    adc_P >>= 4;

    var1 = ((int64_t) bmp280->t_fine) - 128000;
    var2 = var1 * var1 * (int64_t) bmp280->_bmp280_calib.dig_P6;
    var2 = var2 + ((var1 * (int64_t) bmp280->_bmp280_calib.dig_P5) << 17);
    var2 = var2 + (((int64_t) bmp280->_bmp280_calib.dig_P4) << 35);
    var1 = ((var1 * var1 * (int64_t) bmp280->_bmp280_calib.dig_P3) >> 8) +
            ((var1 * (int64_t) bmp280->_bmp280_calib.dig_P2) << 12);
    var1 =
            (((((int64_t) 1) << 47) + var1)) * ((int64_t) bmp280->_bmp280_calib.dig_P1) >> 33;

    if (var1 == 0) {
        return 0; // avoid exception caused by division by zero
    }
    p = 1048576 - adc_P;
    p = (((p << 31) - var2) * 3125) / var1;
    var1 = (((int64_t) bmp280->_bmp280_calib.dig_P9) * (p >> 13) * (p >> 13)) >> 25;
    var2 = (((int64_t) bmp280->_bmp280_calib.dig_P8) * p) >> 19;

    p = ((p + var1 + var2) >> 8) + (((int64_t) bmp280->_bmp280_calib.dig_P7) << 4);
    return (float) p / 256;
}

/*!
 * @brief Calculates the approximate altitude using barometric pressure and the
 * supplied sea level hPa as a reference.
 * @param seaLevelhPa
 *        The current hPa at sea level.
 * @return The approximate altitude above sea level in meters.
 */
/*
float BMP280_readAltitude(Adafruit_BMP280 * bmp280, float seaLevelhPa) {
    float altitude;

    float pressure = BMP280_readPressure(bmp280); // in Si units for Pascal
    pressure /= 100;

    altitude = 44330 * (1.0 - pow(pressure / seaLevelhPa, 0.1903));

    return altitude;
}
 */

/*!
 * Calculates the pressure at sea level (QFH) from the specified altitude,
 * and atmospheric pressure (QFE).
 * @param  altitude      Altitude in m
 * @param  atmospheric   Atmospheric pressure in hPa
 * @return The approximate pressure in hPa
 */
/*
float BMP280_seaLevelForAltitude(Adafruit_BMP280 * bmp280, float altitude, float atmospheric) {
    // Equation taken from BMP180 datasheet (page 17):
    // http://www.adafruit.com/datasheets/BST-BMP180-DS000-09.pdf

    // Note that using the equation from wikipedia can give bad results
    // at high altitude.  See this thread for more information:
    // http://forums.adafruit.com/viewtopic.php?f=22&t=58064
    return atmospheric / pow(1.0 - (altitude / 44330.0), 5.255);
}
 */

/*!
    @brief  calculates the boiling point  of water by a given pressure
    @param pressure pressure in hPa
    @return temperature in °C
 */
/*
float BMP280_waterBoilingPoint(Adafruit_BMP280 * bmp280, float pressure) {
    // Magnusformular for calculation of the boiling point of water at a given
    // pressure
    return (234.175 * log(pressure / 6.1078)) /
            (17.08085 - log(pressure / 6.1078));
}
 */

/*!
    @brief  Take a new measurement (only possible in forced mode)
    @return true if successful, otherwise false
 */
int BMP280_takeForcedMeasurement(Adafruit_BMP280 * bmp280) {
    // If we are in forced mode, the BME sensor goes back to sleep after each
    // measurement and we need to set it to forced mode once at this point, so
    // it will take the next measurement and then return to sleep again.
    // In normal mode simply does new measurements periodically.
    if ((bmp280->_measReg & 0x03) == MODE_FORCED) {
        // set to forced mode, i.e. "take next measurement"
        BMP280_write8(bmp280, BMP280_REGISTER_CONTROL, bmp280->_measReg);
        // wait until measurement has been completed, otherwise we would read
        // the values from the last measurement
        while (BMP280_read8(bmp280, BMP280_REGISTER_STATUS) & 0x08)
            delay(1);
        return 1;
    }
    return 0;
}

/*!
 *  @brief  Resets the chip via soft reset
 */
void BMP280_reset(Adafruit_BMP280 * bmp280) {
    BMP280_write8(bmp280, BMP280_REGISTER_SOFTRESET, MODE_SOFT_RESET_CODE);
}

/*!
    @brief  Gets the most recent sensor event from the hardware status register.
    @return Sensor status as a uint8_t.
 */
uint8_t BMP280_getStatus(Adafruit_BMP280 * bmp280) {
    return BMP280_read8(bmp280, BMP280_REGISTER_STATUS);
}



