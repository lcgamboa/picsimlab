#include "config.h"

typedef enum {
    SLAVE_10BITS_INT = 0x2F,
    SLAVE_7BITS_INT = 0x2E,
    FMASTER = 0x2B,
    MASTER = 0x28,
    SLAVE_10BITS = 0x27,
    SLAVE_7BITS = 0x26
} I2C_Mode;


static int addr = 0;

void i2cBegin(uint8_t _addr, I2C_Mode sMode) {
    TRISC3 = 1; //SCK
    TRISC4 = 1; //SDA


    SSPADD = (_XTAL_FREQ / (4 * 100000L)) - 1;
    SSPSTAT = 0x80;

    SSPCON1 = sMode;

    PIR1bits.SSPIF = 0;

    addr = _addr << 1;
}

void i2c_write(uint8_t * bout, uint8_t size) {

    SSPCON2bits.SEN = 1;
    while (!PIR1bits.SSPIF);
    PIR1bits.SSPIF = 0;

    SSPBUF = addr;
    while (!PIR1bits.SSPIF);
    PIR1bits.SSPIF = 0;

    for (uint8_t i = 0; i < size; i++) {
        SSPBUF = bout[i];
        while (!PIR1bits.SSPIF);
        PIR1bits.SSPIF = 0;
    }

    SSPCON2bits.PEN = 1;
    while (!PIR1bits.SSPIF);
    PIR1bits.SSPIF = 0;
}

void i2c_write_then_read(uint8_t * bout, uint8_t sout, uint8_t * bin, uint8_t sin) {
    uint8_t i;


    SSPCON2bits.SEN = 1;
    while (!PIR1bits.SSPIF);
    PIR1bits.SSPIF = 0;

    SSPBUF = addr;
    while (!PIR1bits.SSPIF);
    PIR1bits.SSPIF = 0;

    for (i = 0; i < sout; i++) {
        SSPBUF = bout[i];
        while (!PIR1bits.SSPIF);
        PIR1bits.SSPIF = 0;
    }

    SSPCON2bits.RSEN = 1;
    while (!PIR1bits.SSPIF);
    PIR1bits.SSPIF = 0;


    SSPBUF = addr | 0x01;
    while (!PIR1bits.SSPIF);
    PIR1bits.SSPIF = 0;

    for (i = 0; i < sin; i++) {

        SSPCON2bits.RCEN = 1;
        while (!PIR1bits.SSPIF);
        PIR1bits.SSPIF = 0;
        bin[i] = SSPBUF;

        SSPCON2bits.ACKDT = (i + 1 == sin) ? 1 : 0; //ACK/NACK
        SSPCON2bits.ACKEN = 1;
        while (!PIR1bits.SSPIF);
        PIR1bits.SSPIF = 0;
    }

    SSPCON2bits.PEN = 1;
    while (!PIR1bits.SSPIF);
    PIR1bits.SSPIF = 0;
}


