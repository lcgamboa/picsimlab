#include "config.h"
#include <stdio.h>
/***************************************************************************
  This is a library for the BMP280 humidity, temperature & pressure sensor
  This example shows how to take Sensor Events instead of direct readings

  Designed specifically to work with the Adafruit BMP280 Breakout
  ----> http://www.adafruit.com/products/2651

  These sensors use I2C or SPI to communicate, 2 or 4 pins are required
  to interface.

  Adafruit invests time and resources providing this open source code,
  please support Adafruit and open-source hardware by purchasing products
  from Adafruit!

  Written by Limor Fried & Kevin Townsend for Adafruit Industries.
  BSD license, all text above must be included in any redistribution
 ***************************************************************************/




#include "Adafruit_BMP280.h"


Adafruit_BMP280 bmp; // use SPI interface

char buffer[20];

void setup() {

    unsigned status;

    //BMP280_INIT_I2C(&bmp, BMP280_ADDRESS);
    BMP280_INIT_SPI(&bmp, _RD3);

    status = BMP280_begin(&bmp, BMP280_CHIPID);

    if (!status) {
        serial_tx_str("Could not find a valid BMP280 sensor, check wiring or try a different address!");
        serial_tx_str("SensorID was: ");
        sprintf(buffer, "0x%02X", bmp._sensorID);
        serial_tx_str(buffer);
        serial_tx_str("\n");
        serial_tx_str("        ID of 0xFF probably means a bad address, a BMP 180 or BMP 085\n");
        serial_tx_str("   ID of 0x56-0x58 represents a BMP 280,\n");
        serial_tx_str("        ID of 0x60 represents a BME 280.\n");
        serial_tx_str("        ID of 0x61 represents a BME 680.\n");

        while (1) delay(10);
    }

    // Default settings from datasheet. 
    BMP280_setSampling(&bmp, MODE_NORMAL, // Operating Mode. 
            SAMPLING_X2, // Temp. oversampling 
            SAMPLING_X16, // Pressure oversampling 
            FILTER_X16, // Filtering. 
            STANDBY_MS_500); // Standby time. 

}

void loop() {

    if (serial_rx(0)) {

        float temp = BMP280_readTemperature(&bmp);
        float press = BMP280_readPressure(&bmp);

        serial_tx_str("T= ");
        sprintf(buffer, "%6.2f", temp);
        serial_tx_str(buffer);
        serial_tx_str(" P= ");
        sprintf(buffer, "%6.2f", press / 100.0);
        serial_tx_str(buffer);
        serial_tx_str("\n");
    }
    //delay(500);
}
