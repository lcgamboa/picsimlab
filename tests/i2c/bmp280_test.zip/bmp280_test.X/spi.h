
#include "config.h" 

typedef enum
{
  MASTER_OSC_DIV4  = 0x20,
  MASTER_OSC_DIV16 = 0x21,
  MASTER_OSC_DIV64 = 0x22,
  MASTER_TMR2_DIV2 = 0x23,
  SLAVE_SS_EN      = 0x24,
  SLAVE_SS_DIS     = 0x25
}Spi_Mode;

typedef enum
{
  SAMPLE_MIDDLE = 0x00,
  SAMPLE_END    = 0x80
}Spi_Data_Sample;

typedef enum
{
  IDLE_HIGH = 0x10,
  IDLE_LOW  = 0x00
}Spi_Clock_Pol;

typedef enum
{
  IDLE_TO_ACTIVE = 0x00,
  ACTIVE_TO_IDLE = 0x40
}Spi_Clock_Edge;


static int ncs = 0 ;

void spiBegin(uint8_t _cspin, Spi_Mode sMode, Spi_Data_Sample sDataSample, Spi_Clock_Edge sClockEdge, Spi_Clock_Pol sClockPol)
{
  TRISC5 = 0; //SDO
  TRISC4 = 1; //SDI
  if(sMode & 0x04) //If Slave Mode
  {
    SSPSTAT = sClockEdge;
    TRISC3 = 1;//SCLK
  }
  else //If Master Mode
  {
    SSPSTAT = sDataSample | sClockEdge;
    TRISC3 = 0;//SCLK
  }
  SSPCON1 = sMode | sClockPol;
  
  ncs =_cspin;
  pinMode(ncs, OUTPUT);
  digitalWrite(ncs, 1);
}


/*
void spiWrite(char dat){
    SSPBUF = dat;
}

char spiRead(){
    if(SSPSTATbits.BF){
        return SSPBUF;
    }
    return 0;
}
*/
void spi_write(uint8_t * bout, uint8_t size){
    digitalWrite(ncs, 0);
    //clear BF 
    uint8_t dummy = SSPBUF;
    
    for(uint8_t i=0; i < size; i++){
        SSPBUF = bout[i];
        
       while(!SSPSTATbits.BF);
    
       //clear BF 
       dummy = SSPBUF;          
    }
    digitalWrite(ncs, 1);
}

void spi_write_then_read(uint8_t * bout, uint8_t sout, uint8_t * bin, uint8_t sin){
    uint8_t i;
    //clear BF 
    uint8_t dummy = SSPBUF;
   
    digitalWrite(ncs, 0);
    for(i=0; i < sout; i++){ 
       SSPBUF = bout[i];
       while(!SSPSTATbits.BF);
       //clear BF 
       dummy = SSPBUF;
    }
    
    for(i=0; i < sin; i++){
       SSPBUF = 0xFF;
       while(!SSPSTATbits.BF);
       bin[i]= SSPBUF;  
    }
    digitalWrite(ncs, 1);
}


