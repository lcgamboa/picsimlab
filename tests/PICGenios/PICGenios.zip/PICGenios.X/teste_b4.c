/* ########################################################################

   PICsim - PIC simulator http://sourceforge.net/projects/picsim/

   ########################################################################

   Copyright (c) : 2022  Luis Claudio Gamb�a Lopes

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

   For e-mail suggestions :  lcgamboa@yahoo.com
   ######################################################################## */

/* ----------------------------------------------------------------------- */

#include <xc.h>


#include "config.h"


#include "atraso.h"
#include "lcd.h"
#include "display7s.h"
#if defined(_18F4550 ) || defined(_18F45K50 )  
#else
#include "i2c.h"
#include "eeprom_ext.h"
#include "rtc.h"
#endif
#include "serial.h"
#if !defined(_16F777) && !defined(_18F47K40)
#include "eeprom.h"
#endif
#include "adc.h"
#include "itoa.h"
#include "teclado.h"


#ifndef _16F777
__EEPROM_DATA(0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77);
__EEPROM_DATA(0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF);
#endif

void teste_ADC(void);
void teste_EEPROM_EXT(void);
void teste_EEPROM_INT(void);
void teste_LCD(void);
void teste_RTC(void);
void teste_display7s(void);
void teste_serial(void);
void teste_teclado2(unsigned char num);
void teste_temperatura(void);

unsigned char cnt;
unsigned int t1cont;

//char buffer[45];

void waitbtn(void) {
    while (PORTBbits.RB1);
    atraso_ms(100);
    while (!PORTBbits.RB1);
    atraso_ms(100);
}

void main() {

    TRISA = 0xC3;
    TRISB = 0x01;
    TRISC = 0x01;
    TRISD = 0x00;
    TRISE = 0x00;

#if defined(_18F47K40)
    ANSELA = 0x07;
    ANSELB = 0;
    ANSELC = 0;
    ANSELD = 0;
    ANSELE = 0;
#endif

#if defined(_16F877A) || defined(_16F777)  || defined(_18F47K40) 
#else  
    INTCON2bits.RBPU = 0;
#endif

    lcd_init();
    lcd_cmd(L_NCR);
#if defined(_18F4550 ) || defined(_18F45K50 )  
#else    
    i2c_init();
#endif  
    adc_init();
#ifndef _18F47K40
#ifdef _18F452
    ADCON1 = 0x06;
#else
    ADCON1 = 0x0F;
#if !defined(_18F45K50) && !defined(_18F47K40)  
    CMCON = 0x07;
#endif  
#endif
#endif
    PORTA = 0;
    PORTCbits.RC1 = 1; //desliga beep
    PORTCbits.RC5 = 0; //desliga aquecedor
    PORTCbits.RC6 = 0;

    //dip
    TRISB = 0x03;

    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("Turn off only");
    lcd_cmd(L_L2);
    lcd_str("RTC and REL1 DIP");
    while (PORTBbits.RB1);
    waitbtn();

    teste_LCD();
    teste_display7s();
    teste_serial();
    teste_ADC();
    teste_temperatura();
    teste_RTC();
    teste_teclado2(12);
    teste_EEPROM_INT();
    teste_EEPROM_EXT();


    //fim teste 
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("      END");
    lcd_cmd(L_L2);
    lcd_str(" Press RESET");


    while (1);

}



//----------------------------------------------------------------------------
// High priority interrupt routine

void interrupt isrh() {
    cnt--;
    if (!cnt) {
        //executada a cada 1 segundo
        t1cont = (((unsigned int) TMR1H << 8) | (TMR1L)) / 7; //ventilador com 7 p�s
        cnt = 125;
        TMR1H = 0;
        TMR1L = 0;
    }
#ifdef _18F47K40
    PIR0bits.TMR0IF = 0;
#else 
    INTCONbits.T0IF = 0;
#endif 
#if defined(_16F877A) || defined(_16F777)  
    TMR0 = 6;
#else
    TMR0H = 0;
    TMR0L = 6; //250 
#endif
}

//----------------------------------------------------------------------------

#if defined(_16F877A) || defined(_16F777)  
#else

void interrupt low_priority isrl() {
#asm
    NOP
#endasm
}
#endif

void teste_LCD(void) {
    unsigned char i, tmp;

    //testa caracter especial
    lcd_cmd(L_NCR);
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("   Test LCD L1");
    lcd_cmd(L_L2);
    lcd_str("   Test LCD L2");
    waitbtn();
}

void teste_display7s(void) {
    unsigned char i, tmp;

    //testa display 7s

    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("   Test 7 Seg");

#ifndef _18F47K40
#ifdef _18F452
    ADCON1 = 0x06;
#else
    ADCON1 = 0x0F;
#endif
#endif    

    PORTA = 0x3C;
    PORTD = display7s(2);
    waitbtn();
    PORTD = display7s(8);
    waitbtn();
    PORTA = 0x00;

#ifndef _18F47K40
#ifdef _18F452
    ADCON1 = 0x02;
#else
    ADCON1 = 0x0B;
#endif
    PORTD = 0;
#endif
}

void teste_serial(void) {
    unsigned char i, tmp;

    //teste serial
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("Test Serial");
    // testar ? 
    lcd_cmd(L_L2);
    lcd_str(" (N=RB0 Y=RB1) ?");

    TRISB = 0x03;
    while (PORTBbits.RB0 && PORTBbits.RB1);

    if (PORTBbits.RB1 == 0) {

        TRISCbits.TRISC7 = 1; //RX
        TRISCbits.TRISC6 = 0; //TX
        serial_init();

        lcd_cmd(L_CLR);
        lcd_cmd(L_L1);
        lcd_str("Test Serial");
        serial_tx_str(" Type!\r\n");
        for (i = 0; i < 16; i++) {
            if (!(i % 16)) {
                lcd_cmd(L_L2);
                serial_tx_str("\r\n");
            }
            tmp = serial_rx(5000);
            lcd_dat(tmp);
            serial_tx(tmp);
        }
        atraso_ms(100);
        serial_end();
        PORTCbits.RC6 = 0;
    }
}

void teste_ADC(void) {
    unsigned char i;
    unsigned char tmp;
    char str[6];

    //teste ADC
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str(" Test ADC (P1)");

    do {
        tmp = (adc_amostra(0)*10) / 204;
        lcd_cmd(L_L2 + 6);
        itoa(tmp, str);
        lcd_dat(str[3]);
        lcd_dat('.');
        lcd_dat(str[4]);
        lcd_dat('V');
        atraso_ms(10);
    } while (PORTBbits.RB1);

    while (!PORTBbits.RB1);

    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str(" Test ADC (P2)");

    do {
        tmp = ((unsigned int) adc_amostra(1)*10) / 204;
        lcd_cmd(L_L2 + 6);
        itoa(tmp, str);
        lcd_dat(str[3]);
        lcd_dat('.');
        lcd_dat(str[4]);
        lcd_dat('V');
        atraso_ms(10);
    } while (PORTBbits.RB1);

    while (!PORTBbits.RB1);

}

void teste_temperatura(void) {
    unsigned char i;
    unsigned int tmpi;
    char str[6];

    //teste TEMP
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("Test TEMPERATURE");

    TRISA = 0x07;

    adc_init();

    do {
        tmpi = (adc_amostra(2)*10) / 2;
        lcd_cmd(L_L2 + 5);
        itoa(tmpi, str);
        lcd_dat(str[2]);
        lcd_dat(str[3]);
        lcd_dat('.');
        lcd_dat(str[4]);
        lcd_dat('C');
        atraso_ms(20);
    } while (PORTBbits.RB1);
    while (!PORTBbits.RB1);


    //teste Aquecimento
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("   Test Heater");
    PORTCbits.RC5 = 1;
    PORTCbits.RC6 = 1;
    do {
        tmpi = (adc_amostra(2)*10) / 2;
        lcd_cmd(L_L2 + 5);
        itoa(tmpi, str);
        lcd_dat(str[2]);
        lcd_dat(str[3]);
        lcd_dat('.');
        lcd_dat(str[4]);
        lcd_dat('C');
        atraso_ms(50);
    } while (PORTBbits.RB1);
    while (!PORTBbits.RB1);

    PORTCbits.RC5 = 0;
    PORTCbits.RC6 = 0;

    //teste Resfriamento

    TRISCbits.TRISC0 = 1;
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("   Test Cooler");

    //timer0 temporizador
#if defined(_16F877A) || defined(_16F777)  
    OPTION_REGbits.T0CS = 0;
    OPTION_REGbits.PSA = 0;
    OPTION_REGbits.PS0 = 0;
    OPTION_REGbits.PS1 = 0;
    OPTION_REGbits.PS2 = 1;
#elif _18F47K40
    T0CON0bits.T0OUT = 0;
    T0CON0bits.T016BIT = 0;
    T0CON0bits.T0OUTPS = 0;

    T0CON1bits.T0CS = 2; //FOSC/4
    T0CON1bits.T0ASYNC = 0;
    T0CON1bits.T0CKPS = 5; // 32

    T0CON0bits.T0EN = 1;
    TMR0H = 255;
#else
    T0CONbits.T0CS = 0;
    T0CONbits.PSA = 0;
    T0CONbits.T08BIT = 1;
    T0CONbits.T0PS0 = 0; // divide por 32
    T0CONbits.T0PS1 = 0;
    T0CONbits.T0PS2 = 1;
    T0CONbits.TMR0ON = 1;
#endif

#ifdef _18F47K40
    PIE0bits.TMR0IE = 1;
#else 
    INTCONbits.T0IE = 1;
#endif
    //T = 32x250x125 = 1segundo;

    //timer1 contador
#ifdef _18F47K40
    T1CONbits.CKPS = 0;
    TMR1CLKbits.CS = 1; //FOSC/4

    T1CONbits.ON = 1;
#else 
    T1CONbits.TMR1CS = 1;
    T1CONbits.T1CKPS1 = 0;
    T1CONbits.T1CKPS0 = 0;
#endif 

#ifdef _18F47K40
    PIR0bits.TMR0IF = 0;
#else 
    INTCONbits.T0IF = 0;
#endif 
#if defined(_16F877A) || defined(_16F777)  
    TMR0 = 6;
#else
    TMR0H = 0;
    TMR0L = 6; //250
#endif
    cnt = 125;
    INTCONbits.GIE = 1;

    TMR1H = 0;
    TMR1L = 0;
    T1CONbits.TMR1ON = 1;

    PORTCbits.RC2 = 1;
    do {
        tmpi = (adc_amostra(2)*10) / 2;
        lcd_cmd(L_L2 + 2);
        itoa(tmpi, str);
        lcd_dat(str[2]);
        lcd_dat(str[3]);
        lcd_dat('.');
        lcd_dat(str[4]);
        lcd_dat('C');

        lcd_cmd(L_L2 + 8);
        itoa(t1cont, str);
        lcd_dat(str[1]);
        lcd_dat(str[2]);
        lcd_dat(str[3]);
        lcd_dat(str[4]);
        lcd_dat('R');
        lcd_dat('P');
        lcd_dat('S');

        atraso_ms(10);
    } while (PORTBbits.RB1);
    while (!PORTBbits.RB1);

    INTCONbits.GIE = 0;
    PORTCbits.RC2 = 0;


#ifdef _18F452
    ADCON1 = 0x06;
#else
    ADCON1 = 0x0F;
#endif

}

void teste_RTC(void) {
#if defined(_18F4550 ) || defined(_18F45K50 )  
#else 
    //teste RTC
    lcd_cmd(L_CLR);
    do {
        rtc_r();
        lcd_cmd(L_L1);
        lcd_str("RTC: ");
        lcd_str((const char *) date);
        lcd_cmd(L_L2);
        lcd_str("     ");
        lcd_str((const char *) time);
        atraso_ms(250);
    } while (PORTBbits.RB1);
    while (!PORTBbits.RB1);
#endif
}

void teste_teclado2(unsigned char num) {
    unsigned char i;
    unsigned char tmp;

    TRISB = 0x07;
    PORTB |= 0x07;
    //teste Teclado
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1 + 2);
    lcd_str("Test Keyboard");

    lcd_cmd(L_L2 + 1);

    i = 0;
    while (i < num) {
        tmp = tc_tecla(5000) + 0x30;
        if (!(i % 15)) {
            lcd_cmd(L_L2 + 1);
        }
        lcd_dat(tmp);
        i++;
    }
    waitbtn();
}

void teste_EEPROM_INT(void) {
#if  !defined(_16F777) &&  !defined(_18F47K40)
    unsigned char tmp;
    unsigned char i;

    TRISB = 0x03;
    //teste EEPROM INT
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("Test EEPROM INT");
    // testar ? 
    lcd_cmd(L_L2);
    lcd_str(" (N=RB0 Y=RB1) ?");


    TRISB = 0x03;

    while (PORTBbits.RB0 && PORTBbits.RB1);

    if (!PORTBbits.RB1) {
        while (!PORTBbits.RB1);
        tmp = e2prom_r(10);
        lcd_dat(tmp);

        e2prom_w(10, 0xA5);
        e2prom_w(10, 0x5A);
        i = e2prom_r(10);

        e2prom_w(10, tmp);

        lcd_cmd(L_CLR);
        lcd_cmd(L_L1);
        lcd_str("Test EEPROM INT");
        lcd_cmd(L_L2);
        if (i == 0x5A)
            lcd_str("       OK");
        else
            lcd_str("      ERRO");
        atraso_ms(200);
        waitbtn();
    } else {
        while (!PORTBbits.RB0);
    }
#endif
}

void teste_EEPROM_EXT(void) {
#if defined(_18F4550 ) || defined(_18F45K50 )  
#else  
    unsigned char tmp, i;

    //teste EEPROM EXT
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1);
    lcd_str("Test EEPROM EXT");
    // testar ? 
    lcd_cmd(L_L2);
    lcd_str(" (N=RB0 Y=RB1) ?");

    TRISB = 0x03;

    while (PORTBbits.RB0 && PORTBbits.RB1);

    if (!PORTBbits.RB1) {
        while (!PORTBbits.RB1);

        e2pext_w(10, 0xA5);
        tmp = e2pext_r(10);

        e2pext_w(10, 0x5A);
        i = e2pext_r(10);

        lcd_cmd(L_CLR);
        lcd_cmd(L_L1);
        lcd_str("Test EEPROM EXT");
        lcd_cmd(L_L2);
        if (i == 0x5A)
            lcd_str("       OK");
        else
            lcd_str("      ERRO");
        atraso_ms(200);
        waitbtn();
    } else {
        while (!PORTBbits.RB0);
    }
#endif
    TRISB = 0x00;
    PORTB = 0;
}