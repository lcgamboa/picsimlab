#include "config.h"
#include <stdio.h>

#define ADCMAX 1023
#define ANALOGIN _RA0
#define LED1  _RC2
#define PBUTTON _RB0
#define LED2  _RB3

static int bstate = 0;

void interrupt isr(void) {
    if (INTCONbits.INT0F) {
        bstate = digitalRead(PBUTTON);
        INTCON2bits.INTEDG0 = !INTCON2bits.INTEDG0;
        INTCONbits.INT0F = 0;
    }
}

void setup() {
    serial_init();
    pinMode(ANALOGIN, INPUT);
    pinMode(PBUTTON, INPUT);
    pinMode(LED1, OUTPUT);
    pinMode(LED2, OUTPUT);

    digitalWrite(LED1, LOW);
    digitalWrite(LED2, LOW);

    INTCON2bits.INTEDG0 = 1;
    INTCONbits.INT0E = 1;
    INTCONbits.GIE = 1;

}

unsigned int value;
unsigned char value2;
char buffer[50];

void loop() {
    value = analogRead(ANALOGIN);
    value2 = (value * 255L) / ADCMAX;


    analogWrite(LED1, value2);

    digitalWrite(LED2, bstate);
    sprintf(buffer, "AD=%04d PWM=%03d BT=%d\n", value, value2, bstate);
    serial_tx_str(buffer);
    delay(250);
}